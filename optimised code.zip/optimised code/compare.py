# compare_with_sarimax.py

import pandas as pd
import numpy as np
import joblib
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from statsmodels.tsa.statespace.sarimax import SARIMAX
import cupy as cp

# GPU builder for the lagged matrix
from preprocessing import build_lagged_matrix_gpu

def main():
    # 1) Load saved ARX model
    best = joblib.load("best_arx_model.pkl")
    p_star = best["p"]
    b_star = best["b"]
    phi_star = best["phi"]
    eta_star = best["eta"]
    # stack into one CPU array
    theta_star_np = np.concatenate([phi_star, eta_star.flatten()])

    # 2) Load raw data
    df = pd.read_csv("smart_grid_dataset.csv")
    y_np    = df["Predicted Load (kW)"].values
    exog_np = df[[
        "Voltage (V)", "Current (A)", "Power Factor",
        "Solar Power (kW)", "Wind Power (kW)", "Grid Supply (kW)",
        "Temperature (°C)", "Humidity (%)", "Electricity Price (USD/kWh)"
    ]].values

    # 3) Build A, y_target on GPU
    A_gpu, y_gpu = build_lagged_matrix_gpu(y_np, exog_np, p_star, b_star)

    # 4) Convert entire GPU arrays back to NumPy ONCE
    A = cp.asnumpy(A_gpu)
    y = cp.asnumpy(y_gpu)

    # 5) Train/test split in NumPy
    A_tr, A_te, y_tr, y_te = train_test_split(
        A, y, test_size=0.2, random_state=42
    )

    # 6) Prepare exogenous for SARIMAX (drop first p_star columns)
    exog_tr = A_tr[:, p_star:]
    exog_te = A_te[:, p_star:]

    # 7) Fit SARIMAX on CPU
    sarimax = SARIMAX(
        endog=y_tr,
        exog=exog_tr,
        order=(p_star, 0, 0),
        enforce_stationary=False,
        enforce_invertible=False
    )
    res = sarimax.fit(disp=False)
    y_pred_sarimax = res.predict(start=0, end=len(y_te)-1, exog=exog_te)
    mse_sarimax = np.mean((y_te - y_pred_sarimax)**2)

    # 8) Custom ARX prediction on GPU
    #    Move only the test-split to GPU along with theta
    A_te_gpu        = cp.asarray(A_te,        dtype=cp.float64)
    theta_star_gpu  = cp.asarray(theta_star_np, dtype=cp.float64)

    y_pred_custom_gpu = A_te_gpu.dot(theta_star_gpu)
    y_pred_custom     = cp.asnumpy(y_pred_custom_gpu)
    mse_custom        = np.mean((y_te - y_pred_custom)**2)

    # 9) Report
    print(f"Best lags → p* = {p_star}, b* = {b_star}")
    print(f"Custom ARX GPU MSE: {mse_custom:.4f}")
    print(f"SARIMAX CPU   MSE: {mse_sarimax:.4f}")

    # 10) Plot the first 100 test samples
    plt.figure(figsize=(10,5))
    plt.plot(y_te[:100],            label="Actual",       linewidth=2)
    plt.plot(y_pred_custom[:100],   label="Custom ARX",    linestyle="--")
    plt.plot(y_pred_sarimax[:100],  label="SARIMAX",       linestyle=":")
    plt.title("Load Forecast: Custom ARX (GPU) vs SARIMAX (CPU)")
    plt.xlabel("Sample Index")
    plt.ylabel("Load (kW)")
    plt.legend()
    plt.tight_layout()
    plt.show()

if __name__=="__main__":
    main()
